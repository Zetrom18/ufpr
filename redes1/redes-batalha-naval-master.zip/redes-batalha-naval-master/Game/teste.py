import BattleShip as bs

board = bs.BattleShip(5,2)

board.print_board()