import random
import json

class ModelRepository:

    def __init__(self):
        self.modelos = ["Cascata", "Espiral"]

    def listar(self):
        return self.modelos

    def buscar(self, key):
        return self.modelos[key]

class GameRepository:
    def __init__(self):
        self.cargos = {
            '1': 'Analista',
            '2': 'Projetista',
            '3': 'BD',
            '4': 'programador',
            '5': 'testador'
        }

class DescRepository:

    def __init__(self):
        self.projs = []
        with open("descProj.json", "r") as f:
            data = json.loads(f.read())
            print(data)
            for nome in data:
                self.projs.append({"nome": nome, "desc": data[nome]})

    def get_random(self):
        return random.choice(self.projs)

