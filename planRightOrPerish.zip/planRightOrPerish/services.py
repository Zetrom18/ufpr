from repositories import ModelRepository
from models import Projeto, Desenvolvedor


class PlayerService:
    def __init__(self):
        self.modelRepo = ModelRepository()
        self.projeto = Projeto()

    def escolhe_modelo(self, indice):
        try:
            self.projeto.defineModelo(self.modelRepo.buscar(int(indice) - 1), self.projeto.orcamento)

            return self.projeto.modelo.nome
        except:
            print("opção invalida, escolhendo 1")
            self.projeto.defineModelo(self.modelRepo.buscar(0), self.projeto.orcamento)
            return self.projeto.modelo.nome

    def estabelece_cronograma(self, tempoEstimado):
        try:
            self.projeto.estabeleceCronograma(int(tempoEstimado))
        except:
            print("cronograma invalido, esolhendo 100 dias")
            self.projeto.estabeleceCronograma(100)

    def estabelece_orcamento(self, orcamento):
        try:
            self.projeto.estabeleceOrcamento(float(orcamento))
        except:
            print("orcamento invalido, esolhendo 10.000 BitCruzadosReais")
            self.projeto.estabeleceOrcamento(10000.0)

    def define_tapa(self):
        try:
            self.etapaAtual = self.projeto.modelo.etapas[self.projeto.modelo.etapaAtiva]
        except:
            print("Erro ao definir etapa")

    def contrata_desenvolvedor(self, cargo, salario, range_salario):
        try:
            # com range = 500, 5000:
            # 100 (nivel max) - ((quanto falta pro maximo)/100.
            # salario 5000 nivel = 100
            # salario 3000 nivel = 80
            # salario 2000 nivel = 70
            # salario 500 nivel = 55
            nivel = 100 - ((range_salario[1] - float(salario)) / 100)
            novo_desenvolvedor = Desenvolvedor(cargo, salario, nivel)
            self.projeto.desenvolvedores.append(novo_desenvolvedor)
            print('{} contratado como {} nível {}. salario: {} BCR'.format(novo_desenvolvedor.nome,
                                                                           novo_desenvolvedor.cargo,
                                                                           novo_desenvolvedor.nivel,
                                                                           novo_desenvolvedor.salario))
        except Exception as ex:
            print("Erro ao contratar desenvolvedor")
            print(str(ex))

    def demite_desenvolvedor(self, id):
        try:
            print(id)
            del self.projeto.desenvolvedores[int(id)]
        except Exception as ex:
            print("Erro ao demitir desenvolvedor - id invalido")
            print(str(ex))


# class GameService:
#     def __init__(self):
#